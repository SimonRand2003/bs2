package ui;

import domain.MatchDB;

public class app {
    public static void main (String[] args){
        MatchDB db = new  MatchDB();
    }

}
